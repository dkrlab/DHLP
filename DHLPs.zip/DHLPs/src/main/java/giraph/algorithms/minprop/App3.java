package giraph.algorithms.minprop;

/**
 * Hello world!
 *
 */
import org.apache.giraph.graph.BasicComputation;
import org.apache.giraph.GiraphRunner;
import org.apache.giraph.edge.Edge;
import org.apache.giraph.Classes.LPVertexValue;
import org.apache.giraph.Classes.Message1;
import org.apache.giraph.graph.Vertex;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;

import org.apache.hadoop.util.ToolRunner;

//import org.apache.log4j.Logger;


import java.io.IOException;


public class App3 extends BasicComputation<
        LongWritable, LPVertexValue, FloatWritable, Message1> {

    /**
     * Class logger
     */

    //private static final Logger LOG = Logger.getLogger(App.class);

    double neighbour[] = new double[13504];
    double neighbours_fi[] = new double[13504];

    @Override
    public void compute(
            Vertex<LongWritable, LPVertexValue, FloatWritable> vertex,
            Iterable<Message1> messages) throws IOException {
        int count_neighbour = vertex.getNumEdges();
      /*  double neighbour[] = new double[count_neighbour];
        double neighbours_fi[] = new double[count_neighbour];*/

        int finall = 0;
        boolean flag = false;
        //agar message my_final_fi true bashad amaliyate motamemgiri anjam mishavad
       // if (getSuperstep() == 10)
         //   vertex.voteToHalt();
    //    else {
            if (getSuperstep() != 0) {
            /*  if(vertex.getId().get() == 6)
              {
                  int count_Neighbour = 0;
                  for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                      sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(), vertex.getValue().gety_i(), vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), vertex.getValue().getneighbour()[count_Neighbour], false, false, false, true));
                      count_Neighbour = count_Neighbour + 1;
                  }
              }*/
                for (int count = 0; count < count_neighbour; count++)
                    neighbour[count] = vertex.getValue().getneighbour()[count];
                for (Message1 message : messages) {
                    if (message.Is_Final_Fi()) { //dige tamoom bayad beshe
                        if (vertex.getId().get() == 1002 && !flag) {
                            int count_Neighbour = 0;
                            for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                                sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(), vertex.getValue().gety_i(), vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), vertex.getValue().getneighbour()[count_Neighbour], false, false, false, true));
                                count_Neighbour = count_Neighbour + 1;
                            }
                        }
                        flag = true;
                        finall = finall + 1;
                        int count = 0;
                        for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                            if (edge.getTargetVertexId().get() == message.get_Id()) {
                                neighbour[count] = 0.5 * vertex.getValue().getneighbour()[count] + 0.5 * message.get_Neighbour();
                                //  a[count] = vertex.getValue().getneighbour()[count];
                            }
                            count = count + 1;
                        }

                    }
                }
                vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(), vertex.getValue().gety_prim(), vertex.getValue().getLastf(), vertex.getValue().getCurrentf(), vertex.getValue().getf_old(), vertex.getValue().getf_i(), count_neighbour, neighbour, neighbours_fi, vertex.getValue().getIteration(), vertex.getValue().getnum_neighbour(), vertex.getValue().IsEnd(), vertex.getValue().getCount_End(), vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), vertex.getValue().getLine6or9()));
            }
            //agar message start ferestade shavad tavasote node akhar har nodi be hamsayeganash fi khod raa etela midahad
            for (Message1 message : messages)
                if (message.Is_Start()) { //lazem nist amaliyat anjam beshe
                    flag = true;
                    int count_Neighbour = 0;
                    for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                        sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(), vertex.getValue().gety_i(), vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), vertex.getValue().getneighbour()[count_Neighbour], false, false, false, true));
                        count_Neighbour = count_Neighbour + 1;
                    }

                }
//Master_Prev va Master_Current avaz mishavad
            for (Message1 message : messages) //eshkal nadare anjam beshe
                if (/*vertex.getValue().IsEnd() &&*/ message.get_yi() == 1 && (message.get_Id() != vertex.getValue().getMaster_Current())) {
                    for (int count = 0; count < count_neighbour; count++) {
                        neighbours_fi[count] = 0;
                    }
                    vertex.setValue(new LPVertexValue(0, 0, 0, 0, 0, 0, count_neighbour, vertex.getValue().getneighbour(), neighbours_fi, 0, 0, false, 0, vertex.getValue().getMaster_Current(), message.get_Id(), false));
                }
            // agar Vertex Master Bashad yi=1 mishavad va be hame etela dade mishavad

            for (Message1 message : messages)
                if (message.Is_Master() == true) {// anjam nashe
                    flag = true;
                    vertex.setValue(new LPVertexValue(1, 0, 0, 0, 0, 1, count_neighbour, vertex.getValue().getneighbour(), vertex.getValue().getneighbours_fi(), 0, 0, false, 0, message.get_Id(), vertex.getId().get(), false));
                    int count_Neighbour = 0;
                    for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                        sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(), vertex.getValue().gety_i(), vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), vertex.getValue().getneighbour()[count_Neighbour], false, false, false, false));
                        count_Neighbour = count_Neighbour + 1;
                    }
                }
            //agar tedade messagehaye End shode be n-1 berasad node digari master mishavad va khodash adi mishavd
            if (getSuperstep() != 0) {
                for (int cnt = 0; cnt < count_neighbour; cnt++)
                    neighbour[cnt] = vertex.getValue().getneighbour()[cnt];

                for (Message1 message : messages)
                    if (message.Is_End() == true)
                        if (vertex.getValue().gety_i() == 1) {

                            int counter = 0;
                            for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                                if (edge.getTargetVertexId().get() == message.get_Id()) {
                                    neighbour[counter] = message.get_Fi();

                                }
                                counter = counter + 1;
                            }

                            vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(), vertex.getValue().gety_prim(), vertex.getValue().getLastf(), vertex.getValue().getCurrentf(), vertex.getValue().getf_old(), vertex.getValue().getf_i(), count_neighbour, neighbour, vertex.getValue().getneighbours_fi(), vertex.getValue().getIteration(), vertex.getValue().getnum_neighbour(), vertex.getValue().IsEnd(), vertex.getValue().getCount_End() + 1, vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), vertex.getValue().getLine6or9()));
                            if (vertex.getValue().getCount_End() >= 998)
                                if (vertex.getId().get() == 997) {
                                    //lazem nist anjam beshavad
                                    for (int count = 0; count < count_neighbour; count++) {
                                        neighbours_fi[count] = 0;
                                    }
                                    int count_Neighbour = 0;
                                    flag = true;
                                    vertex.setValue(new LPVertexValue(0, 0, 0, 0, 0, 0, count_neighbour, vertex.getValue().getneighbour(), neighbours_fi, 0, 0, false, vertex.getValue().getCount_End(), vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), false));
                                    for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                                        if (edge.getTargetVertexId().get() == 2)
                                            sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(), vertex.getValue().gety_i(), vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), vertex.getValue().getneighbour()[count_Neighbour], false, true, false, false));
                                        count_Neighbour = count_Neighbour + 1;
                                    }
                                } else if (vertex.getId().get() == 998) {
                                    for (int count = 0; count < count_neighbour; count++) {
                                        neighbours_fi[count] = 0;
                                    }
                                    int count_Neighbour = 0;
                                    flag = true;
                                    vertex.setValue(new LPVertexValue(0, 0, 0, 0, 0, 0, count_neighbour, vertex.getValue().getneighbour(), neighbours_fi, 0, 0, false, vertex.getValue().getCount_End(), vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), false));
                                    for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                                        if (edge.getTargetVertexId().get() == 3)
                                            sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(), vertex.getValue().gety_i(), vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), vertex.getValue().getneighbour()[count_Neighbour], false, true, false, false));
                                        count_Neighbour = count_Neighbour + 1;
                                    }
                                } else if (vertex.getId().get() == 1002) {
                                    for (int count = 0; count < count_neighbour; count++) {
                                        neighbours_fi[count] = 0;
                                    }
                                    int count_Neighbour = 0;
                                    flag = true;
                                    vertex.setValue(new LPVertexValue(0, 0, 0, 0, 0, 0, count_neighbour, vertex.getValue().getneighbour(), neighbours_fi, 0, 0, false, vertex.getValue().getCount_End(), vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), false));
                                    for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                                        sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(), vertex.getValue().gety_i(), vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), vertex.getValue().getneighbour()[count_Neighbour], false, false, true, false));
                                        count_Neighbour = count_Neighbour + 1;
                                    }
                                } else {
                                    int count_Neighbour = 0;
                                    flag = true;
                                    for (int count = 0; count < count_neighbour; count++) {
                                        neighbours_fi[count] = 0;
                                    }
                                    vertex.setValue(new LPVertexValue(0, 0, 0, 0, 0, 0, count_neighbour, vertex.getValue().getneighbour(), neighbours_fi, 0, 0, false, vertex.getValue().getCount_End(), vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), false));
                                    for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                                        if (edge.getTargetVertexId().get() == vertex.getId().get() + 3)
                                            sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(), vertex.getValue().gety_i(), vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), vertex.getValue().getneighbour()[count_Neighbour], false, true, false, false));
                                        count_Neighbour = count_Neighbour + 1;

                                    }

                                }

                        }

            }
            if (getSuperstep() == 0) {
                for (int count = 0; count < count_neighbour; count++) {
                    neighbour[count] = 0;
                    neighbours_fi[count] = 0;
                }
                vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(), vertex.getValue().gety_prim(), vertex.getValue().getLastf(), vertex.getValue().getCurrentf(), vertex.getValue().getf_old(), vertex.getValue().getf_i(), count_neighbour, neighbour, neighbours_fi, vertex.getValue().getIteration(), vertex.getValue().getnum_neighbour(), vertex.getValue().IsEnd(), 0, 1, 1, false));

                if (vertex.getValue().gety_i() == 1) {
                    int count_Neighbour = 0;
                    for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                        sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(), vertex.getValue().gety_i(), vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), vertex.getValue().getneighbour()[count_Neighbour], false, false, false, false));
                        count_Neighbour = count_Neighbour + 1;
                    }
                }
            }

            // else
            //{

            else if (vertex.getValue().getCurrentf() == 0 && !vertex.getValue().IsEnd() && !vertex.getValue().getLine6or9() && !flag) {
                int count = 0;
                double y_prim;
                for (int cnt = 0; cnt < count_neighbour; cnt++)
                    neighbours_fi[cnt] = vertex.getValue().getneighbours_fi()[cnt];

                int counter = 0;

                for (Message1 message : messages) {
                    for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                        if (edge.getTargetVertexId().get() == message.get_Id()) {
                            if (vertex.getId().get() % 3 !=  message.get_Id() % 3)
                                neighbours_fi[counter] = message.get_Fi();
                            // a[count] = 1.5;

                        }
                        counter = counter + 1;
                    }
                    counter = 0;
                }
                vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(), vertex.getValue().gety_prim(), vertex.getValue().getLastf(), vertex.getValue().getCurrentf(), vertex.getValue().getf_old(), vertex.getValue().getf_i(), count_neighbour, vertex.getValue().getneighbour(), neighbours_fi, vertex.getValue().getIteration(), vertex.getValue().getnum_neighbour(), vertex.getValue().IsEnd(), vertex.getValue().getCount_End(), vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), true));

                y_prim = 0.5 * vertex.getValue().gety_i();

                for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                    if (vertex.getId().get() % 3 != edge.getTargetVertexId().get() % 3) {

                        y_prim += 0.5 * edge.getValue().get() * vertex.getValue().getneighbours_fi()[count];
                    }
                    count = count + 1;
                }

                vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(), y_prim, vertex.getValue().getLastf(), 0.5 * y_prim, vertex.getValue().getf_old(), vertex.getValue().getf_i(), count_neighbour, vertex.getValue().getneighbour(), vertex.getValue().getneighbours_fi(), vertex.getValue().getIteration(), vertex.getValue().getnum_neighbour(), vertex.getValue().IsEnd(), vertex.getValue().getCount_End(), vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), true));
                int count_Neighbour = 0;
                int counter2 = 0;
                for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                  //  if(counter2<11500)
                    //{
                        counter2 = counter2 + 1;
                        sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(), vertex.getValue().gety_i(), vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), vertex.getValue().getneighbour()[count_Neighbour], false, false, false, false));
                    //}
                    count_Neighbour = count_Neighbour + 1;
                }
            } else if (!vertex.getValue().IsEnd() && !flag && vertex.getValue().getLine6or9())//khate 9
            {


          /*      if (Math.abs(vertex.getValue().getCurrentf() - vertex.getValue().getLastf()) < 0.05 && getSuperstep()>2) {
                    vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(), vertex.getValue().gety_prim(), 0, 0, vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), count_neighbour, vertex.getValue().getneighbour(),vertex.getValue().getneighbours_fi(), vertex.getValue().getIteration() + 1, false, vertex.getValue().getCount_End(), vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(),false));

                    if ((vertex.getValue().getf_old() != 0 || vertex.getValue().getf_i() != 0) && Math.abs(vertex.getValue().getf_i() - vertex.getValue().getf_old()) < 1)
                        vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(), vertex.getValue().gety_prim(), 0, 0, vertex.getValue().getf_old(), vertex.getValue().getf_i(), count_neighbour, vertex.getValue().getneighbour(),vertex.getValue().getneighbours_fi(), vertex.getValue().getIteration(), true, vertex.getValue().getCount_End(), vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(),vertex.getValue().getLine6or9()));

                    else if ((vertex.getValue().getf_old() == 0 && vertex.getValue().getf_i() == 0) && vertex.getValue().getIteration() == 3)
                        vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(), vertex.getValue().gety_prim(), 0, 0, vertex.getValue().getf_old(), vertex.getValue().getf_i(), count_neighbour, vertex.getValue().getneighbour(),vertex.getValue().getneighbours_fi(), vertex.getValue().getIteration(), true, vertex.getValue().getCount_End(), vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(),vertex.getValue().getLine6or9()));
                    //   else
                    //     vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(),vertex.getValue().gety_i_next(),vertex.getValue().gety_prim(),0,0,vertex.getValue().getf_i(),vertex.getValue().getCurrentf(),count_neighbour,vertex.getValue().getneighbour(),vertex.getValue().getIteration()+1,false,vertex.getValue().getCount_End(),vertex.getValue().getMaster_Prev(),vertex.getValue().getMaster_Current()));

                    if (vertex.getValue().IsEnd() == true && vertex.getValue().gety_i() != 1) {
                        int count_Neighbour = 0;
                        for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                            sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(), vertex.getValue().gety_i(), vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), vertex.getValue().getneighbour()[count_Neighbour], true, false, false, false));
                            count_Neighbour = count_Neighbour + 1;
                        }
                    }
                }*/
                //else {asli

                for (int cnt = 0; cnt < count_neighbour; cnt++)
                    neighbours_fi[cnt] = vertex.getValue().getneighbours_fi()[cnt];

                int counter = 0;


                for (Message1 message : messages) {
                    for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                        if (edge.getTargetVertexId().get() == message.get_Id()) {
                            if (vertex.getId().get() % 3 ==  message.get_Id() % 3)
                                if (message.get_Fit() != 0)
                                    neighbours_fi[counter] = message.get_Fit();
                                else
                                    neighbours_fi[counter] = message.get_Fi();

                        }
                        counter = counter + 1;
                    }
                    counter = 0;
                }
                vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(), vertex.getValue().gety_prim(), vertex.getValue().getLastf(), vertex.getValue().getCurrentf(), vertex.getValue().getf_old(), vertex.getValue().getf_i(), count_neighbour, vertex.getValue().getneighbour(), neighbours_fi, vertex.getValue().getIteration(), vertex.getValue().getnum_neighbour(), vertex.getValue().IsEnd(), vertex.getValue().getCount_End(), vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), vertex.getValue().getLine6or9()));

                int count = 0;
                double fi_t = 0.5 * vertex.getValue().gety_prim();
                for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                    if (vertex.getId().get() % 3 == edge.getTargetVertexId().get() % 3) {

                        fi_t += 0.5 * edge.getValue().get() * vertex.getValue().getneighbours_fi()[count];
                    }
                    count = count + 1;
                }
                vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(), vertex.getValue().gety_prim(), vertex.getValue().getCurrentf(), fi_t, vertex.getValue().getf_old(), vertex.getValue().getf_i(), count_neighbour, vertex.getValue().getneighbour(), vertex.getValue().getneighbours_fi(), vertex.getValue().getIteration(), vertex.getValue().getnum_neighbour(), vertex.getValue().IsEnd(), vertex.getValue().getCount_End(), vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), vertex.getValue().getLine6or9()));

                //      }asli
                if (Math.abs(vertex.getValue().getCurrentf() - vertex.getValue().getLastf()) < 0.01  /*|| vertex.getValue().getIteration_InnerLoop() == 3*//*&& getSuperstep()>2*/) {
                    vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(), vertex.getValue().gety_prim(), 0, 0, vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), count_neighbour, vertex.getValue().getneighbour(), vertex.getValue().getneighbours_fi(), vertex.getValue().getIteration() + 1, 0, false, vertex.getValue().getCount_End(), vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), false));

                    if ((vertex.getValue().getf_old() != 0 || vertex.getValue().getf_i() != 0) && Math.abs(vertex.getValue().getf_i() - vertex.getValue().getf_old()) < 0.01)
                        vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(), vertex.getValue().gety_prim(), 0, 0, vertex.getValue().getf_old(), vertex.getValue().getf_i(), count_neighbour, vertex.getValue().getneighbour(), vertex.getValue().getneighbours_fi(), vertex.getValue().getIteration(), 0, true, vertex.getValue().getCount_End(), vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), vertex.getValue().getLine6or9()));

                    else if ((vertex.getValue().getf_old() == 0 && vertex.getValue().getf_i() == 0) && vertex.getValue().getIteration() == 3)
                        vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(), vertex.getValue().gety_prim(), 0, 0, vertex.getValue().getf_old(), vertex.getValue().getf_i(), count_neighbour, vertex.getValue().getneighbour(), vertex.getValue().getneighbours_fi(), vertex.getValue().getIteration(), 0, true, vertex.getValue().getCount_End(), vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), vertex.getValue().getLine6or9()));
                    //   else
                    //     vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(),vertex.getValue().gety_i_next(),vertex.getValue().gety_prim(),0,0,vertex.getValue().getf_i(),vertex.getValue().getCurrentf(),count_neighbour,vertex.getValue().getneighbour(),vertex.getValue().getIteration()+1,false,vertex.getValue().getCount_End(),vertex.getValue().getMaster_Prev(),vertex.getValue().getMaster_Current()));

                   /* if (vertex.getValue().IsEnd() == true && vertex.getValue().gety_i() != 1) {
                        int count_Neighbour = 0;
                        for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                            sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(), vertex.getValue().gety_i(), vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), vertex.getValue().getneighbour()[count_Neighbour], true, false, false, false));
                            count_Neighbour = count_Neighbour + 1;
                        }
                    }*/


                }

                if (vertex.getValue().IsEnd() == true && vertex.getValue().gety_i() != 1) {
                    int count_Neighbour = 0;
                    for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                        sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(), vertex.getValue().gety_i(), vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), vertex.getValue().getneighbour()[count_Neighbour], true, false, false, false));
                        count_Neighbour = count_Neighbour + 1;
                    }
                } else {
                    int count_Neighbour = 0;
                    for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                        sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(), vertex.getValue().gety_i(), vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), vertex.getValue().getneighbour()[count_Neighbour], false, false, false, false));
                        count_Neighbour = count_Neighbour + 1;
                    }
                }
            }
            vertex.voteToHalt();
            //  }
  /* public static void main(String[]args)throws Exception
    {
        System.exit(ToolRunner.run(new GiraphRunner(), args));
    }*/
            //  vertex.voteToHalt();
            // }
            // vertex.voteToHalt();
        //}
    }
}