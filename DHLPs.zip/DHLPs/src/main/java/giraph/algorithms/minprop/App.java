package giraph.algorithms.minprop;

/**
 * Hello world!
 *
 */
import org.apache.giraph.graph.BasicComputation;
import org.apache.giraph.GiraphRunner;
import org.apache.giraph.edge.Edge;
import org.apache.giraph.Classes.LPVertexValue;
import org.apache.giraph.Classes.Message1;
import org.apache.giraph.graph.Vertex;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;

import org.apache.hadoop.util.ToolRunner;

//import org.apache.log4j.Logger;


import java.io.IOException;


public class App extends BasicComputation<
        LongWritable, LPVertexValue, FloatWritable, Message1> {

    /**
     * Class logger
     */

    //private static final Logger LOG = Logger.getLogger(App.class);



    @Override
    public void compute(
            Vertex<LongWritable, LPVertexValue, FloatWritable> vertex,
            Iterable<Message1> messages) throws IOException {
        /*int count_neighbour = vertex.getNumEdges();
        double a [] = new double[count_neighbour];
        double a1 [] = new double[count_neighbour];


        if(getSuperstep() == 89)
        {
            int count_Neighbour = 0;
            for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(),vertex.getValue().gety_i(),vertex.getValue().getf_i(), vertex.getValue().getCurrentf(),vertex.getValue().getneighbour()[count_Neighbour],false,false,false,false));
                count_Neighbour = count_Neighbour +1;
            }
        }
       else if(getSuperstep() == 90)
        {

            int count = 0 ;
           for (Message1 message : messages) {
                for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                    if (edge.getTargetVertexId().get() == message.get_Id()) {
                      a[count] = 0.5*vertex.getValue().getneighbour()[count]+0.5*message.get_Neighbour();
                      //  a[count] = vertex.getValue().getneighbour()[count];

                    }
                    count = count+1;
                }
                count = 0;
            }
            vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(), vertex.getValue().gety_prim(), vertex.getValue().getLastf(), vertex.getValue().getCurrentf(),vertex.getValue().getf_old(),vertex.getValue().getf_i(), count_neighbour,a,a1,vertex.getValue().getIteration(),vertex.getValue().IsEnd(),vertex.getValue().getCount_End(),vertex.getValue().getMaster_Prev(),vertex.getValue().getMaster_Current(),false));

            vertex.voteToHalt();
        }
        else if((getSuperstep()+2)%15==0)
        {
            int count_Neighbour = 0;
            for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(),vertex.getValue().gety_i(),vertex.getValue().getf_i(), vertex.getValue().getCurrentf(),vertex.getValue().getneighbour()[count_Neighbour],false,false,false,false));
                count_Neighbour = count_Neighbour +1;
            }
        }
        else if((getSuperstep()+1)%15==0) {
            int count = 0;

            if (vertex.getValue().gety_i() == 1) {

                for (Message1 message : messages) {
                    for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                        if (edge.getTargetVertexId().get() == message.get_Id()) {
                            a[count] = message.get_Fi();
                            // a[count] = 1.5;

                        }
                        count = count + 1;
                    }
                    count = 0;
                }
                vertex.setValue(new LPVertexValue(0.0, 0.0, 0.0, 0.0, 0.0,0.0, 0.0, count_neighbour, a,vertex.getValue().getIteration(),vertex.getValue().IsEnd(),vertex.getValue().getCount_End(),vertex.getValue().getMaster_Prev(),vertex.getValue().getMaster_Current(),false));
                //vertex.voteToHalt();
            } else if (vertex.getValue().gety_i_next() == 1) {
                vertex.setValue(new LPVertexValue(1.0, 0.0, 0.0, 0.0, 0.0,0.0, 1.0, count_neighbour, vertex.getValue().getneighbour(),vertex.getValue().getIteration(),vertex.getValue().IsEnd(),vertex.getValue().getCount_End(),vertex.getValue().getMaster_Prev(),vertex.getValue().getMaster_Current(),false));
                // else vertex.voteToHalt();
            }
            else
                vertex.setValue(new LPVertexValue(0.0, 0.0, 0.0, 0.0, 0.0,0.0, 0.0, count_neighbour, vertex.getValue().getneighbour(),vertex.getValue().getIteration(),vertex.getValue().IsEnd(),vertex.getValue().getCount_End(),vertex.getValue().getMaster_Prev(),vertex.getValue().getMaster_Current(),false));
        }
        else if (getSuperstep()%15== 0) {
            if(getSuperstep() == 0) {
                for(int count=0;count<count_neighbour;count++)
                    a[count] = 0;
                vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(), vertex.getValue().gety_i_next(), vertex.getValue().gety_prim(), vertex.getValue().getLastf(), vertex.getValue().getCurrentf(),vertex.getValue().getf_old(),vertex.getValue().getf_i(), count_neighbour, a,vertex.getValue().getIteration(),vertex.getValue().IsEnd(),vertex.getValue().getCount_End(),vertex.getValue().getMaster_Prev(),vertex.getValue().getMaster_Current(),false));
            }

            int count_Neighbour = 0;
            for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(),vertex.getValue().gety_i(),vertex.getValue().getf_i(), vertex.getValue().getCurrentf(),vertex.getValue().getneighbour()[count_Neighbour],false,false,false,false));
                count_Neighbour = count_Neighbour +1;
            }
          //  if(vertex.getId().get()==1 || vertex.getId().get()==2 || vertex.getId().get() == 3)
            //    vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(),0,vertex.getValue().gety_prim(),vertex.getValue().getLastf(),vertex.getValue().getCurrentf(),1,count_neighbour,a));
            //for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
              //  sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(), vertex.getValue().getf_i(), vertex.getValue().getCurrentf(),2.5));

            //}
        }
        else
        {

            if (vertex.getValue().getCurrentf() == 0) {
                int count = 0;
                double y_prim = 0;
                for (Message1 message : messages)
                    if(message.get_yi() == 1)
                        if((vertex.getId().get() == (message.get_Id()+3)) ||(message.get_Id() == 4 && vertex.getId().get()==2)|| (message.get_Id() == 5 && vertex.getId().get()==3))
                            vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(),1,vertex.getValue().gety_prim(),vertex.getValue().getLastf(),vertex.getValue().getCurrentf(),vertex.getValue().getf_old(),vertex.getValue().getf_i(),count_neighbour,vertex.getValue().getneighbour(),vertex.getValue().getIteration(),vertex.getValue().IsEnd(),vertex.getValue().getCount_End(),vertex.getValue().getMaster_Prev(),vertex.getValue().getMaster_Current(),false));

                for (Message1 message : messages) {
                    for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                        if (edge.getTargetVertexId().get() == message.get_Id()) {
                            if (vertex.getId().get() % 3 != (long) message.get_Id() % 3) {
                                if (count == 0) {
                                    y_prim = 0.333 * vertex.getValue().gety_i() + 0.333 * edge.getValue().get() * message.get_Fi();
                                    count++;
                                } else {
                                    y_prim += 0.333 * edge.getValue().get() * message.get_Fi();

                                }
                            }
                        }

                    }
                }
                vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(),vertex.getValue().gety_i_next(),y_prim,vertex.getValue().getLastf(),0.75 * y_prim,vertex.getValue().getf_old(),vertex.getValue().getf_i(),count_neighbour,vertex.getValue().getneighbour(),vertex.getValue().getIteration(),vertex.getValue().IsEnd(),vertex.getValue().getCount_End(),vertex.getValue().getMaster_Prev(),vertex.getValue().getMaster_Current(),false));
                int count_Neighbour = 0;
                for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                    sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(),vertex.getValue().gety_i(),vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), vertex.getValue().getneighbour()[count_Neighbour],false,false,false,false));
                    count_Neighbour = count_Neighbour + 1;
                }
            }
            else //khate 9
            {


                if (Math.abs(vertex.getValue().getCurrentf() - vertex.getValue().getLastf()) < 1) {



                    vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(),vertex.getValue().gety_i_next(),vertex.getValue().gety_prim(),0,0,vertex.getValue().getf_old(),vertex.getValue().getCurrentf(),count_neighbour,vertex.getValue().getneighbour(),vertex.getValue().getIteration(),vertex.getValue().IsEnd(),vertex.getValue().getCount_End(),vertex.getValue().getMaster_Prev(),vertex.getValue().getMaster_Current(),false));

                } else {
                    for (Message1 message : messages)
                        if(message.get_yi() == 1)
                         if(vertex.getId().get() == message.get_Id()+3 ||(message.get_Id() == 4 && vertex.getId().get()==2)|| (message.get_Id() == 5 && vertex.getId().get()==3))
                                vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(),1,vertex.getValue().gety_prim(),vertex.getValue().getLastf(),vertex.getValue().getCurrentf(),vertex.getValue().getf_old(),vertex.getValue().getf_i(),count_neighbour,vertex.getValue().getneighbour(),vertex.getValue().getIteration(),vertex.getValue().IsEnd(),vertex.getValue().getCount_End(),vertex.getValue().getMaster_Prev(),vertex.getValue().getMaster_Current(),false));
                    double fi_t = 0.75 * vertex.getValue().gety_prim();

                    for (Message1 message : messages) {
                        for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                            if (edge.getTargetVertexId().get() == message.get_Id()) {
                                if (vertex.getId().get() % 3 == (long) message.get_Id() % 3)
                                    fi_t = fi_t + 0.25 * edge.getValue().get() * message.get_Fit();

                            }

                        }
                    }
                    vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(),vertex.getValue().gety_i_next(),vertex.getValue().gety_prim(),vertex.getValue().getCurrentf(),fi_t,vertex.getValue().getf_old(),vertex.getValue().getf_i(),count_neighbour,vertex.getValue().getneighbour(),vertex.getValue().getIteration(),vertex.getValue().IsEnd(),vertex.getValue().getCount_End(),vertex.getValue().getMaster_Prev(),vertex.getValue().getMaster_Current(),false));

                }

                int count_Neighbour = 0;
                for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                    sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(),vertex.getValue().gety_i(),vertex.getValue().getf_i(), vertex.getValue().getCurrentf(),vertex.getValue().getneighbour()[count_Neighbour],false,false,false,false));
                    count_Neighbour = count_Neighbour+1;
            }

        }
        //  if(getSuperstep() == 20)
        //  vertex.voteToHalt();

    }
  /* public static void main(String[]args)throws Exception
    {
        System.exit(ToolRunner.run(new GiraphRunner(), args));
    }*/
}
}