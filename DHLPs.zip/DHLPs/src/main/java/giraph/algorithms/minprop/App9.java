package giraph.algorithms.minprop;

/**
 * Hello world!
 *
 */
import org.apache.giraph.graph.BasicComputation;
import org.apache.giraph.GiraphRunner;
import org.apache.giraph.edge.Edge;
import org.apache.giraph.Classes.LPVertexValue;
import org.apache.giraph.Classes.Message1;
import org.apache.giraph.graph.Vertex;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;

import org.apache.hadoop.util.ToolRunner;

//import org.apache.log4j.Logger;


import java.io.IOException;


public class App9 extends BasicComputation<
        LongWritable, LPVertexValue, FloatWritable, Message1> {

    /**
     * Class logger
     */

    //private static final Logger LOG = Logger.getLogger(App.class);





    @Override
    public void compute(
            Vertex<LongWritable, LPVertexValue, FloatWritable> vertex,
            Iterable<Message1> messages) throws IOException {
        int count_neighbour = vertex.getNumEdges();
        double neighbour [] = new double[371];
        double neighbours_fi [] = new double[371];

        boolean flag_exist[] = new boolean[371];


        for (int count = 0; count < count_neighbour; count++) {
            flag_exist[count] = false;
        }

        int flag_counter2 = 0;
        for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
            if (edge.getValue().get() != 0) {
                flag_exist[flag_counter2] = true;
            }
            flag_counter2 = flag_counter2 + 1;
        }


        boolean flag = false;
        //agar message my_final_fi true bashad amaliyate motamemgiri anjam mishavad



          if (getSuperstep() != 0) {
              for (int count = 0; count < count_neighbour; count++) {
                  neighbours_fi[count] = vertex.getValue().getneighbours_fi()[count];
              }
              int Vertex_Index = 0;
              if (vertex.getId().get() % 3 == 1) {
                  Vertex_Index = (int) vertex.getId().get() / 3;

              }
              if (vertex.getId().get() % 3 == 2) {
                  Vertex_Index = (int) vertex.getId().get() / 3 + 223;
              }
              if (vertex.getId().get() % 3 == 0) {
                  Vertex_Index = (int) vertex.getId().get() / 3 + 275;
              }

              for (Message1 message : messages) {
                  if (message.Is_End()) {
                      if (message.get_Id() % 3 == 1) {
                          int Index = (int) message.get_Id() / 3;
                          if (Vertex_Index < Index) {
                              neighbours_fi[Index - 1] += 2.01;
                          } else {

                              neighbours_fi[Index] += 2.01;
                          }
                      }
                      if (message.get_Id() % 3 == 2) {
                          int Index = (int) message.get_Id() / 3 + 223;
                          if (Vertex_Index < Index)
                              neighbours_fi[Index - 1] += 2.01;
                          else
                              neighbours_fi[Index] += 2.01;

                      }
                      if (message.get_Id() % 3 == 0) {
                          int Index = (int) message.get_Id() / 3 + 275;
                          if (Vertex_Index < Index)
                              neighbours_fi[Index - 1] += 2.01;
                          else
                              neighbours_fi[Index] += 2.01;

                      }
                  }

              }
              vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(), vertex.getValue().gety_prim(), vertex.getValue().getLastf(), vertex.getValue().getCurrentf(), vertex.getValue().getf_old(), vertex.getValue().getf_i(), count_neighbour, vertex.getValue().getneighbour(), neighbours_fi, vertex.getValue().getIteration(), vertex.getValue().getnum_neighbour(), vertex.getValue().IsEnd(), vertex.getValue().getCount_End(), vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), vertex.getValue().getLine6or9()));

          }

          if (getSuperstep() != 0) {
            /*  if(vertex.getId().get() == 6)
              {
                  int count_Neighbour = 0;
                  for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                      sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(), vertex.getValue().gety_i(), vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), vertex.getValue().getneighbour()[count_Neighbour], false, false, false, true));
                      count_Neighbour = count_Neighbour + 1;
                  }
              }*/
              for (int count = 0; count < count_neighbour; count++)
                  neighbour[count] = vertex.getValue().getneighbour()[count];
              for (Message1 message : messages) {
                  if (message.Is_Final_Fi()) { //dige tamoom bayad beshe
                      if (vertex.getId().get() == 285 && !flag) {
                          int count_Neighbour = 0;
                          for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                              sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(), vertex.getValue().gety_i(), vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), vertex.getValue().getneighbour()[count_Neighbour], false, false, false, true));
                              count_Neighbour = count_Neighbour + 1;
                          }
                      }
                      flag = true;
                      int count = 0;
                      int Vertex_Index = 0;
                      if (vertex.getId().get() % 3 == 1) {
                          Vertex_Index = (int) vertex.getId().get() / 3;

                      }
                      if (vertex.getId().get() % 3 == 2) {
                          Vertex_Index = (int) vertex.getId().get() / 3 + 223;
                      }
                      if (vertex.getId().get() % 3 == 0) {
                          Vertex_Index = (int) vertex.getId().get() / 3 + 275;
                      }
                      if (message.get_Id() % 3 == 1) {
                          int Index = (int) message.get_Id() / 3;
                          if (Vertex_Index < Index)
                              neighbour[Index - 1] = 0.5 * vertex.getValue().getneighbour()[Index - 1] + 0.5 * message.get_Neighbour();
                          else
                              neighbour[Index] = 0.5 * vertex.getValue().getneighbour()[Index] + 0.5 * message.get_Neighbour();
                      }
                      if (message.get_Id() % 3 == 2) {
                          int Index = (int) message.get_Id() / 3 + 223;
                          if (Vertex_Index < Index)
                              neighbour[Index - 1] = 0.5 * vertex.getValue().getneighbour()[Index - 1] + 0.5 * message.get_Neighbour();
                          else
                              neighbour[Index] = 0.5 * vertex.getValue().getneighbour()[Index] + 0.5 * message.get_Neighbour();

                      }
                      if (message.get_Id() % 3 == 0) {
                          int Index = (int) message.get_Id() / 3 + 275;
                          if (Vertex_Index < Index)
                              neighbour[Index - 1] = 0.5 * vertex.getValue().getneighbour()[Index - 1] + 0.5 * message.get_Neighbour();
                          else
                              neighbour[Index] = 0.5 * vertex.getValue().getneighbour()[Index] + 0.5 * message.get_Neighbour();

                      }

                   /* for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                        if (edge.getTargetVertexId().get() == message.get_Id()) {
                            neighbour[count] = 0.5 * vertex.getValue().getneighbour()[count] + 0.5 * message.get_Neighbour();
                            //  a[count] = vertex.getValue().getneighbour()[count];

                        }
                        count = count + 1;
                    }*/

                  }
              }
              vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(), vertex.getValue().gety_prim(), vertex.getValue().getLastf(), vertex.getValue().getCurrentf(), vertex.getValue().getf_old(), vertex.getValue().getf_i(), count_neighbour, neighbour, neighbours_fi, vertex.getValue().getIteration(), vertex.getValue().getnum_neighbour(), vertex.getValue().IsEnd(), vertex.getValue().getCount_End(), vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), vertex.getValue().getLine6or9()));
          }
          //agar message start ferestade shavad tavasote node akhar har nodi be hamsayeganash fi khod raa etela midahad
          for (Message1 message : messages)
              if (message.Is_Start()) { //lazem nist amaliyat anjam beshe
                  flag = true;
                  int count_Neighbour = 0;
                  for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                      sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(), vertex.getValue().gety_i(), vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), vertex.getValue().getneighbour()[count_Neighbour], false, false, false, true));
                      count_Neighbour = count_Neighbour + 1;
                  }

              }
//Master_Prev va Master_Current avaz mishavad
          for (Message1 message : messages) //eshkal nadare anjam beshe
              if (/*vertex.getValue().IsEnd() &&*/ message.get_yi() == 1 && (message.get_Id() != vertex.getValue().getMaster_Current())) {
                  for (int count = 0; count < count_neighbour; count++) {
                      neighbours_fi[count] = 0;
                  }
                  vertex.setValue(new LPVertexValue(0, 0, 0, 0, 0, 0, count_neighbour, vertex.getValue().getneighbour(), neighbours_fi, 0, vertex.getValue().getnum_neighbour(), false, 0, vertex.getValue().getMaster_Current(), message.get_Id(), false));
              }
          // agar Vertex Master Bashad yi=1 mishavad va be hame etela dade mishavad

          for (Message1 message : messages)
              if (message.Is_Master() == true) {// anjam nashe
                  for (int count = 0; count < count_neighbour; count++) {
                      neighbours_fi[count] = 0;
                  }
                  flag = true;
                  vertex.setValue(new LPVertexValue(1, 0, 0, 0, 0, 1, count_neighbour, vertex.getValue().getneighbour(), neighbours_fi, 0, vertex.getValue().getnum_neighbour(), false, 0, message.get_Id(), vertex.getId().get(), false));
                  int count_Neighbour = 0;
                  for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                      sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(), vertex.getValue().gety_i(), vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), vertex.getValue().getneighbour()[count_Neighbour], false, false, false, false));
                      count_Neighbour = count_Neighbour + 1;
                  }
              }
          //agar tedade messagehaye End shode be n-1 berasad node digari master mishavad va khodash adi mishavd
          if (getSuperstep() != 0) {
              for (int cnt = 0; cnt < count_neighbour; cnt++)
                  neighbour[cnt] = vertex.getValue().getneighbour()[cnt];
              int NumOfMessages = 0;
              for (Message1 message : messages) {
                  if (message.Is_End() == true)
                      if (vertex.getValue().gety_i() == 1) {

                          int counter = 0;
                          int Vertex_Index = 0;
                          int Index = 0;
                          if (vertex.getId().get() % 3 == 1) {
                              Vertex_Index = (int) vertex.getId().get() / 3;

                          }
                          if (vertex.getId().get() % 3 == 2) {
                              Vertex_Index = (int) vertex.getId().get() / 3 + 223;
                          }
                          if (vertex.getId().get() % 3 == 0) {
                              Vertex_Index = (int) vertex.getId().get() / 3 + 275;
                          }
                          if (message.get_Id() % 3 == 1) {
                              Index = (int) message.get_Id() / 3;
                              if (Vertex_Index < Index)
                                  neighbour[Index - 1] = message.get_Fi();
                              else
                                  neighbour[Index] = message.get_Fi();
                          }
                          if (message.get_Id() % 3 == 2) {
                              Index = (int) message.get_Id() / 3 + 223;
                              if (Vertex_Index < Index)
                                  neighbour[Index - 1] = message.get_Fi();
                              else
                                  neighbour[Index] = message.get_Fi();

                          }
                          if (message.get_Id() % 3 == 0) {
                              Index = (int) message.get_Id() / 3 + 275;
                              if (Vertex_Index < Index)
                                  neighbour[Index - 1] = message.get_Fi();
                              else
                                  neighbour[Index] = message.get_Fi();

                          }


                          if ((Vertex_Index < Index && flag_exist[Index - 1]) || (Vertex_Index > Index && flag_exist[Index]))
                              vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(), vertex.getValue().gety_prim(), vertex.getValue().getLastf(), vertex.getValue().getCurrentf(), vertex.getValue().getf_old(), vertex.getValue().getf_i(), count_neighbour, neighbour, vertex.getValue().getneighbours_fi(), vertex.getValue().getIteration(), vertex.getValue().getnum_neighbour(), vertex.getValue().IsEnd(), vertex.getValue().getCount_End() + 1, vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), vertex.getValue().getLine6or9()));
                          else
                              vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(), vertex.getValue().gety_prim(), vertex.getValue().getLastf(), vertex.getValue().getCurrentf(), vertex.getValue().getf_old(), vertex.getValue().getf_i(), count_neighbour, neighbour, vertex.getValue().getneighbours_fi(), vertex.getValue().getIteration(), vertex.getValue().getnum_neighbour(), vertex.getValue().IsEnd(), vertex.getValue().getCount_End(), vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), vertex.getValue().getLine6or9()));

                          //   vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(), vertex.getValue().gety_prim(), vertex.getValue().getLastf(), vertex.getValue().getCurrentf(), vertex.getValue().getf_old(), vertex.getValue().getf_i(), count_neighbour, neighbour, vertex.getValue().getneighbours_fi(), vertex.getValue().getIteration(), vertex.getValue().getnum_neighbour(), vertex.getValue().IsEnd(), vertex.getValue().getCount_End() + 1, vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), vertex.getValue().getLine6or9()));
                       /* if (vertex.getValue().getCount_End() >= 369)
                            if (vertex.getId().get() == 667) {
                                //lazem nist anjam beshavad
                                for (int count = 0; count < count_neighbour; count++) {
                                    neighbours_fi[count] = 0;
                                }
                                int count_Neighbour = 0;
                                flag = true;
                                vertex.setValue(new LPVertexValue(0, 0, 0, 0, 0, 0, count_neighbour, vertex.getValue().getneighbour(), neighbours_fi, 0,0, false, vertex.getValue().getCount_End(), vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), false));
                                for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                                    if (edge.getTargetVertexId().get() == 2)
                                        sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(), vertex.getValue().gety_i(), vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), vertex.getValue().getneighbour()[count_Neighbour], false, true, false, false));
                                    count_Neighbour = count_Neighbour + 1;
                                }
                            } else if (vertex.getId().get() == 158) {
                                for (int count = 0; count < count_neighbour; count++) {
                                    neighbours_fi[count] = 0;
                                }
                                int count_Neighbour = 0;
                                flag = true;
                                vertex.setValue(new LPVertexValue(0, 0, 0, 0, 0, 0, count_neighbour, vertex.getValue().getneighbour(), neighbours_fi, 0,0, false, vertex.getValue().getCount_End(), vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), false));
                                for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                                    if (edge.getTargetVertexId().get() == 3)
                                        sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(), vertex.getValue().gety_i(), vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), vertex.getValue().getneighbour()[count_Neighbour], false, true, false, false));
                                    count_Neighbour = count_Neighbour + 1;
                                }
                            } else if (vertex.getId().get() == 285) {
                                for (int count = 0; count < count_neighbour; count++) {
                                    neighbours_fi[count] = 0;
                                }
                                int count_Neighbour = 0;
                                flag = true;
                                vertex.setValue(new LPVertexValue(0, 0, 0, 0, 0, 0, count_neighbour, vertex.getValue().getneighbour(), neighbours_fi, 0,0, false, vertex.getValue().getCount_End(), vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), false));
                                for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                                    sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(), vertex.getValue().gety_i(), vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), vertex.getValue().getneighbour()[count_Neighbour], false, false, true, false));
                                    count_Neighbour = count_Neighbour + 1;
                                }
                            } else {
                                int count_Neighbour = 0;
                                flag = true;
                                for (int count = 0; count < count_neighbour; count++) {
                                    neighbours_fi[count] = 0;
                                }
                                vertex.setValue(new LPVertexValue(0, 0, 0, 0, 0, 0, count_neighbour, vertex.getValue().getneighbour(), neighbours_fi, 0,0, false, vertex.getValue().getCount_End(), vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), false));
                                for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                                    if (edge.getTargetVertexId().get() == vertex.getId().get() + 3)
                                        sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(), vertex.getValue().gety_i(), vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), vertex.getValue().getneighbour()[count_Neighbour], false, true, false, false));
                                    count_Neighbour = count_Neighbour + 1;

                                }

                            }*/

                      }
                  NumOfMessages++;
              }
              if (NumOfMessages == 0 && vertex.getValue().gety_i() == 1 && vertex.getValue().getCount_End() >= vertex.getValue().getnum_neighbour() - 1)
                  if (vertex.getId().get() == 667) {
                      //lazem nist anjam beshavad
                      for (int count = 0; count < count_neighbour; count++) {
                          neighbours_fi[count] = 0;
                      }
                      int count_Neighbour = 0;
                      flag = true;
                      vertex.setValue(new LPVertexValue(0, 0, 0, 0, 0, 0, count_neighbour, vertex.getValue().getneighbour(), neighbours_fi, 0, vertex.getValue().getnum_neighbour(), false, 0, vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), false));
                      for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                          if (edge.getTargetVertexId().get() == 2)
                              sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(), vertex.getValue().gety_i(), vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), vertex.getValue().getneighbour()[count_Neighbour], false, true, false, false));
                          count_Neighbour = count_Neighbour + 1;
                      }
                  } else if (vertex.getId().get() == 158) {
                      for (int count = 0; count < count_neighbour; count++) {
                          neighbours_fi[count] = 0;
                      }
                      int count_Neighbour = 0;
                      flag = true;
                      vertex.setValue(new LPVertexValue(0, 0, 0, 0, 0, 0, count_neighbour, vertex.getValue().getneighbour(), neighbours_fi, 0, vertex.getValue().getnum_neighbour(), false, 0, vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), false));
                      for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                          if (edge.getTargetVertexId().get() == 3)
                              sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(), vertex.getValue().gety_i(), vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), vertex.getValue().getneighbour()[count_Neighbour], false, true, false, false));
                          count_Neighbour = count_Neighbour + 1;
                      }
                  } else if (vertex.getId().get() == 285) {
                      for (int count = 0; count < count_neighbour; count++) {
                          neighbours_fi[count] = 0;
                      }
                      int count_Neighbour = 0;
                      flag = true;
                      vertex.setValue(new LPVertexValue(0, 0, 0, 0, 0, 0, count_neighbour, vertex.getValue().getneighbour(), neighbours_fi, 0, vertex.getValue().getnum_neighbour(), false, 0, vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), false));
                      for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                          sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(), vertex.getValue().gety_i(), vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), vertex.getValue().getneighbour()[count_Neighbour], false, false, true, false));
                          count_Neighbour = count_Neighbour + 1;
                      }
                  } else {
                      int count_Neighbour = 0;
                      flag = true;
                      for (int count = 0; count < count_neighbour; count++) {
                          neighbours_fi[count] = 0;
                      }
                      vertex.setValue(new LPVertexValue(0, 0, 0, 0, 0, 0, count_neighbour, vertex.getValue().getneighbour(), neighbours_fi, 0, vertex.getValue().getnum_neighbour(), false, 0, vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), false));
                      for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                          if (edge.getTargetVertexId().get() == vertex.getId().get() + 3)
                              sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(), vertex.getValue().gety_i(), vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), vertex.getValue().getneighbour()[count_Neighbour], false, true, false, false));
                          count_Neighbour = count_Neighbour + 1;

                      }

                  }


          }
          if (getSuperstep() == 0) {
              int Num_Neighbour = 0;
              int flag_counter = 0;
              for (int count = 0; count < count_neighbour; count++) {
                  neighbour[count] = 0;
                  neighbours_fi[count] = 0;
                  flag_exist[count] = false;
              }
              for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                  if (edge.getValue().get() != 0) {
                      flag_exist[flag_counter] = true;
                      Num_Neighbour = Num_Neighbour + 1;

                  }
                  flag_counter = flag_counter + 1;
              }

              vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(), vertex.getValue().gety_prim(), vertex.getValue().getLastf(), vertex.getValue().getCurrentf(), vertex.getValue().getf_old(), vertex.getValue().getf_i(), count_neighbour, neighbour, neighbours_fi, vertex.getValue().getIteration(), Num_Neighbour, vertex.getValue().IsEnd(), 0, 1, 1, false));

              if (vertex.getValue().gety_i() == 1) {
                  int count_Neighbour = 0;
                  for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                      //   if(edge.getValue().get()!=0)
                      sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(), vertex.getValue().gety_i(), vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), vertex.getValue().getneighbour()[count_Neighbour], false, false, false, false));
                      count_Neighbour = count_Neighbour + 1;
                  }
              }
          }

          // else
          //{
          else if (/*vertex.getValue().getCurrentf() == 0 &&*/ !vertex.getValue().IsEnd() /*&& !vertex.getValue().getLine6or9()*/ && !flag) {
              int count = 0;
              double y_prim;
              for (int cnt = 0; cnt < count_neighbour; cnt++)
                  neighbours_fi[cnt] = vertex.getValue().getneighbours_fi()[cnt];


              int Vertex_Index = 0;
              if (vertex.getId().get() % 3 == 1) {
                  Vertex_Index = (int) vertex.getId().get() / 3;

              }
              if (vertex.getId().get() % 3 == 2) {
                  Vertex_Index = (int) vertex.getId().get() / 3 + 223;
              }
              if (vertex.getId().get() % 3 == 0) {
                  Vertex_Index = (int) vertex.getId().get() / 3 + 275;
              }

              for (Message1 message : messages) {
                  if (message.get_Id() % 3 == 1) {
                      int Index = (int) message.get_Id() / 3;
                      // if (vertex.getId().get() % 3 != (long) message.get_Id() % 3) {
                      if (Vertex_Index < Index)
                          if (neighbours_fi[Index - 1] <= 2)
                              neighbours_fi[Index - 1] = message.get_Fi();
                          else
                              neighbours_fi[Index - 1] = message.get_Fi() + 2.01;
                      else if (neighbours_fi[Index] <= 2)
                          neighbours_fi[Index] = message.get_Fi();
                      else
                          neighbours_fi[Index] = message.get_Fi() + 2.01;
                      //  }

                  }
                  if (message.get_Id() % 3 == 2) {
                      int Index = (int) message.get_Id() / 3 + 223;
                      //  if (vertex.getId().get() % 3 != (long) message.get_Id() % 3) {
                      if (Vertex_Index < Index)
                          if (neighbours_fi[Index - 1] <= 2)
                              neighbours_fi[Index - 1] = message.get_Fi();
                          else
                              neighbours_fi[Index - 1] = message.get_Fi() + 2.01;
                      else if (neighbours_fi[Index] <= 2)
                          neighbours_fi[Index] = message.get_Fi();
                      else
                          neighbours_fi[Index] = message.get_Fi() + 2.01;
                      //   }

                  }
                  if (message.get_Id() % 3 == 0) {
                      int Index = (int) message.get_Id() / 3 + 275;
                      //    if (vertex.getId().get() % 3 != (long) message.get_Id() % 3) {
                      if (Vertex_Index < Index)
                          if (neighbours_fi[Index - 1] <= 2)
                              neighbours_fi[Index - 1] = message.get_Fi();
                          else
                              neighbours_fi[Index - 1] = message.get_Fi() + 2.01;
                      else if (neighbours_fi[Index] <= 2)
                          neighbours_fi[Index] = message.get_Fi();
                      else
                          neighbours_fi[Index] = message.get_Fi() + 2.01;
                      //  }

                  }


              }


              vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(), vertex.getValue().gety_prim(), vertex.getValue().getLastf(), vertex.getValue().getCurrentf(), vertex.getValue().getf_old(), vertex.getValue().getf_i(), count_neighbour, vertex.getValue().getneighbour(), neighbours_fi, vertex.getValue().getIteration(), vertex.getValue().getnum_neighbour(), vertex.getValue().IsEnd(), vertex.getValue().getCount_End(), vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), true));

              y_prim = 0.5 * vertex.getValue().getf_i();

              for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                  if (vertex.getId().get() % 3 != edge.getTargetVertexId().get() % 3) {
                      if (vertex.getValue().getneighbours_fi()[count] <= 2)
                          y_prim += 0.5 * edge.getValue().get() * vertex.getValue().getneighbours_fi()[count];
                      else
                          y_prim += 0.5 * edge.getValue().get() * (vertex.getValue().getneighbours_fi()[count] - 2.01);

                  }
                  count = count + 1;
              }

              double fi = 0.5 * y_prim;
              count = 0;

              for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                  if (vertex.getId().get() % 3 == edge.getTargetVertexId().get() % 3) {

                      if (vertex.getValue().getneighbours_fi()[count] <= 2)
                          fi += 0.5 * edge.getValue().get() * vertex.getValue().getneighbours_fi()[count];
                      else
                          fi += 0.5 * edge.getValue().get() * (vertex.getValue().getneighbours_fi()[count] - 2.01);
                  }
                  count = count + 1;
              }


              vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(), y_prim, vertex.getValue().getLastf(), 0.5 * y_prim, vertex.getValue().getf_i(), fi, count_neighbour, vertex.getValue().getneighbour(), vertex.getValue().getneighbours_fi(), vertex.getValue().getIteration() + 1, vertex.getValue().getnum_neighbour(), vertex.getValue().IsEnd(), vertex.getValue().getCount_End(), vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), true));

          /*  if (Math.abs(vertex.getValue().getf_i() - vertex.getValue().getf_old()) <0.01 )
                vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(), vertex.getValue().gety_prim(), 0, 0, vertex.getValue().getf_old(), vertex.getValue().getf_i(), count_neighbour, vertex.getValue().getneighbour(), vertex.getValue().getneighbours_fi(), vertex.getValue().getIteration(),0, true, vertex.getValue().getCount_End(), vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), vertex.getValue().getLine6or9()));
           */

              if (/*(vertex.getValue().getf_old() != 0 || vertex.getValue().getf_i() != 0) &&*/ Math.abs(vertex.getValue().getf_i() - vertex.getValue().getf_old()) < 0.01 && vertex.getValue().gety_i()!=1)
                  vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(), vertex.getValue().gety_prim(), 0, 0, vertex.getValue().getf_old(), vertex.getValue().getf_i(), count_neighbour, vertex.getValue().getneighbour(), vertex.getValue().getneighbours_fi(), vertex.getValue().getIteration(), vertex.getValue().getnum_neighbour(), true, vertex.getValue().getCount_End(), vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), vertex.getValue().getLine6or9()));
              //else if ((vertex.getValue().getf_old() == 0 && vertex.getValue().getf_i() == 0) && vertex.getValue().getIteration() == 3)
              //  vertex.setValue(new LPVertexValue(vertex.getValue().gety_i(), vertex.getValue().gety_prim(), 0, 0, vertex.getValue().getf_old(), vertex.getValue().getf_i(), count_neighbour, vertex.getValue().getneighbour(), vertex.getValue().getneighbours_fi(), vertex.getValue().getIteration(),vertex.getValue().getnum_neighbour(), true, vertex.getValue().getCount_End(), vertex.getValue().getMaster_Prev(), vertex.getValue().getMaster_Current(), vertex.getValue().getLine6or9()));

              if (vertex.getValue().IsEnd() == true && vertex.getValue().gety_i() != 1) {
                  int count_Neighbour = 0;
                  for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                      if ((edge.getValue().get() != 0 && vertex.getValue().getneighbours_fi()[count_Neighbour] <= 2) || edge.getTargetVertexId().get() == vertex.getValue().getMaster_Current())
                          sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(), vertex.getValue().gety_i(), vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), vertex.getValue().getneighbour()[count_Neighbour], true, false, false, false));
                      count_Neighbour = count_Neighbour + 1;
                  }
              } else {
                  int count_Neighbour = 0;
                  for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                      if ((edge.getValue().get() != 0 && vertex.getValue().getneighbours_fi()[count_Neighbour] <= 2))
                          sendMessage(edge.getTargetVertexId(), new Message1(vertex.getId().get(), vertex.getValue().gety_i(), vertex.getValue().getf_i(), vertex.getValue().getCurrentf(), vertex.getValue().getneighbour()[count_Neighbour], false, false, false, false));
                      count_Neighbour = count_Neighbour + 1;
                  }
              }
          }

          if (vertex.getValue().gety_i() != 1)
              vertex.voteToHalt();
          //  }
  /* public static void main(String[]args)throws Exception
    {
        System.exit(ToolRunner.run(new GiraphRunner(), args));
    }*/
          //  vertex.voteToHalt();
          // }
          // vertex.voteToHalt();
    }
}