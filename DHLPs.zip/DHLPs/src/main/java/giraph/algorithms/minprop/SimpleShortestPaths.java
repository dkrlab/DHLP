package giraph.algorithms.minprop;

/**
 * Created by erfan on 5/6/17.
 */

import org.apache.giraph.Algorithm;
import org.apache.giraph.Classes.LPVertexValue;
import org.apache.giraph.GiraphRunner;
import org.apache.giraph.conf.LongConfOption;
import org.apache.giraph.edge.Edge;
import org.apache.giraph.graph.BasicComputation;
import org.apache.giraph.graph.Vertex;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;
import org.apache.giraph.Classes.Message1;

import java.io.IOException;

/**
 * Created by erfan on 4/27/17.
 */

import org.apache.giraph.Algorithm;
import org.apache.giraph.GiraphRunner;
import org.apache.giraph.graph.BasicComputation;
import org.apache.giraph.conf.LongConfOption;
import org.apache.giraph.edge.Edge;
import org.apache.giraph.graph.Vertex;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;

import java.io.IOException;

/**
 * Demonstrates the basic Pregel shortest paths implementation.
 */
@Algorithm(
        name = "Shortest paths",
        description = "Finds all shortest paths from a selected vertex"
)
public class SimpleShortestPaths extends BasicComputation<
        LongWritable, /*Message1*/LPVertexValue, FloatWritable, Message1> {
    /** The shortest paths id */
    public static final LongConfOption SOURCE_ID =
            new LongConfOption("SimpleShortestPathsVertex.sourceId", 1,
                    "The shortest paths id");
    /** Class logger */
    private static final Logger LOG =
            Logger.getLogger(SimpleShortestPaths.class);

    /**
     * Is this vertex the source id?
     *
     * @param vertex Vertex
     * @return True if the source id
     */
    private boolean isSource(Vertex<LongWritable, ?, ?> vertex) {
        return vertex.getId().get() == SOURCE_ID.get(getConf());
    }

    @Override
    public void compute(
            Vertex<LongWritable, /*Message1*/LPVertexValue, FloatWritable> vertex,
            Iterable<Message1> messages) throws IOException {
        double a[] = new double[10];
        a[0] = 1.456;
        if (getSuperstep() == 0) {
            vertex.setValue(new /*Message1*/LPVertexValue(Double.MAX_VALUE,1.5,1.5,1.5,1.5,1.5,2,a,a,0,0,false,0,1,1,false));
        }
        double minDist = isSource(vertex) ? 0d : Double.MAX_VALUE;
        for (Message1 message : messages) {
            minDist = Math.min(minDist, message.get_Fi());
        }
        if (LOG.isDebugEnabled()) {
            LOG.debug("Vertex " + vertex.getId() + " got minDist = " + minDist +
                    " vertex value = " + vertex.getValue());
        }
        if (minDist < vertex.getValue().gety_i()) {
            vertex.setValue(new /*Message1*/LPVertexValue(minDist,1.5,1.5,1.5,1.5,1.5,2,a,a,2,0,false,0,1,1,false));
            for (Edge<LongWritable, FloatWritable> edge : vertex.getEdges()) {
                double distance = minDist + edge.getValue().get();
                if (LOG.isDebugEnabled()) {
                    LOG.debug("Vertex " + vertex.getId() + " sent to " +
                            edge.getTargetVertexId() + " = " + distance);
                }
                sendMessage(edge.getTargetVertexId(), new Message1(1,2,distance,1.5,2,false,false,false,false));
            }
        }
        vertex.voteToHalt();
    }
    public static void main(String[] args)throws Exception
    {
        System.exit(ToolRunner.run(new GiraphRunner(),args));
    }
}
