package org.apache.giraph.Classes;

/**
 * Created by erfan on 5/5/17.
 */

import org.apache.hadoop.io.Writable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

/**
 * Created by erfan on 4/29/17.
 */

import org.apache.hadoop.io.Writable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import org.apache.hadoop.io.Writable;

/**
 * Created by erfan on 2/10/17.
 */
public class Message implements Writable {
    public double Fi;
    public double Fi_t;
    public long Id;
    public Message(long id,double fi, double fi_t)
    {
        Id = id;
        Fi = fi;
        Fi_t = fi_t;
    }
    public void write(DataOutput dataOutput)throws IOException
    {

        dataOutput.writeDouble(Id);
        dataOutput.writeDouble(Fi);
        dataOutput.writeDouble(Fi_t);
    }
    public void readFields(DataInput dataInput) throws IOException {
        Id = dataInput.readLong();
        Fi = dataInput.readDouble();
        Fi_t = dataInput.readDouble();
    }
}
