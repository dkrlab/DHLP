package org.apache.giraph.io.formats;


import org.apache.giraph.Classes.Message1;
import org.apache.giraph.edge.Edge;
import org.apache.giraph.Classes.LPVertexValue;
import org.apache.giraph.graph.Vertex;
import org.apache.giraph.io.formats.TextVertexOutputFormat;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.TaskAttemptContext;

import java.io.IOException;


public class LPTextVertexOutputFormat extends
        TextVertexOutputFormat<LongWritable, LPVertexValue/*Message1*/, FloatWritable> {
    /**
     * Used for splitting the line into the main tokens (vertex id, vertex value
     */
    private static final String VALUE_TOKEN_SEPARATOR = " ";

    /**
     * {@inheritDoc}
     */
    @Override
    public TextVertexWriter createVertexWriter(TaskAttemptContext context) throws
            IOException, InterruptedException {
        return new LabelPropagationTextVertexLineWriter();
    }

    /**
     * Used to convert a {@link LPVertexValue} to a line in the output file.
     */
    private class LabelPropagationTextVertexLineWriter extends
            TextVertexWriterToEachLine {
        /**
         * {@inheritDoc}
         */
        @Override
        protected Text convertVertexToLine(
                Vertex<LongWritable,LPVertexValue/*Message1*/, FloatWritable> vertex) throws
                IOException {
            // vertex id
            StringBuilder sb = new StringBuilder(vertex.getId().toString());
            sb.append(VALUE_TOKEN_SEPARATOR);

            //sb.append(vertex.getValue().get_Fi());
            // vertex value
           /* sb.append(vertex.getValue().getLine6or9());
            sb.append(VALUE_TOKEN_SEPARATOR);
            sb.append(vertex.getValue().getIteration());
            sb.append(VALUE_TOKEN_SEPARATOR);
            sb.append(vertex.getValue().IsEnd());
            sb.append(VALUE_TOKEN_SEPARATOR);
            sb.append(vertex.getValue().gety_i());
            sb.append(VALUE_TOKEN_SEPARATOR);
            sb.append(vertex.getValue().gety_prim());
            sb.append(VALUE_TOKEN_SEPARATOR);
            sb.append(vertex.getValue().getLastf());
            sb.append(VALUE_TOKEN_SEPARATOR);
            sb.append(vertex.getValue().getCurrentf());
            sb.append(VALUE_TOKEN_SEPARATOR);*/
           /* sb.append(vertex.getValue().gety_i());
            sb.append(VALUE_TOKEN_SEPARATOR);*/
           /* sb.append(vertex.getValue().IsEnd());
            sb.append(VALUE_TOKEN_SEPARATOR);
            sb.append(vertex.getValue().getIteration());
            sb.append(VALUE_TOKEN_SEPARATOR);
            sb.append(vertex.getValue().getIteration_InnerLoop());
            sb.append(VALUE_TOKEN_SEPARATOR);*/
            int count = (int)vertex.getValue().getCount();
           /* double fi = vertex.getValue().getf_i();
            sb.append(fi);
            sb.append(VALUE_TOKEN_SEPARATOR);*/
          /*  int print = (int) vertex.getValue().getnum_neighbour();
            sb.append(print);
            sb.append(VALUE_TOKEN_SEPARATOR);*/


           for(int i=0;i<count+1;i++)
            {
               if((vertex.getId().get()-1)%3 == 0) {
                    if ((vertex.getId().get() - 1) / 3 == i) {
                        sb.append(0);
                        sb.append(VALUE_TOKEN_SEPARATOR);
                    }
                }
               else if((vertex.getId().get()-2)%3 == 0) {
                    if ((vertex.getId().get() - 2) / 3 + 223 == i) {
                        sb.append(0);
                        sb.append(VALUE_TOKEN_SEPARATOR);
                    }
                }
                else if((vertex.getId().get())%3 == 0) {
                    if ((vertex.getId().get() - 3) / 3 + 276 == i) {
                        sb.append(0);
                        sb.append(VALUE_TOKEN_SEPARATOR);
                    }
                }
              if(i<count)
              {
                      sb.append(vertex.getValue().getneighbour()[i]);
                      sb.append(VALUE_TOKEN_SEPARATOR);
              }
            }
          /*  sb.append(VALUE_TOKEN_SEPARATOR);
            sb.append(vertex.getValue().getCount());*/

            return new Text(sb.toString());
        }
    }
}
