package org.apache.giraph.Classes;

/**
 * Created by erfan on 5/5/17.
 */

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Writable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

/**
 * Created by erfan on 4/28/17.
 */

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Writable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Writable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;


public class LPVertexValue implements Writable {
    /**
     * The desired partition the vertex want to migrate to.
     */
    private double y_i_current = 0.0;
    private double y_i_next = 0.0;
    private double y_prim = 0.0;
    private double f_last = 0.0;
    private double f_current = 0.0;
    private double f_old = 0.0;
    private double f_i = 0.0;
    private long count_neighbour = 0;
   // private double neighbour[] = new double [100];
    private double neighbour[];
    private double neighbour_fi[];
    private long iteration = 0;
    private long num_neighbour = 0;
    private boolean EndofComputation = false;
    private long count_End = 0;
    private long Master_Prev = 1;
    private long Master_Current = 1;
    private boolean Line6or9 = false;




    /**
     * Default Constructor
     */
    public LPVertexValue() {
    }


    public LPVertexValue(double y_i_current, double y_prim, double f_last, double f_current,double f_old,double f_i,long count_neighbour,double[] neighbour,double[] neighbour_fi,long iteration,long num_neighbour,boolean EndofComputation,long count_End,long Master_Prev,long Master_Current,boolean Line6or9) {
        set(y_i_current,y_prim,f_last,f_current,f_old,f_i,count_neighbour,neighbour,neighbour_fi,iteration,num_neighbour,EndofComputation,count_End,Master_Prev,Master_Current,Line6or9);
        /*this.y_i = y_i;
        this.y_prim = y_prim;
        this.f_old = f_old;
        this.f_current = f_current;
        this.f_i = f_i;*/
    }
    public void set(double y_i_current, double y_prim, double f_last, double f_current,double f_old,double f_i,long count_neighbour,double[] neigh,double[] neighbours_fi,long iteration,long num_neighbour,boolean EndofComputation,long count_End,long Master_Prev,long Master_Current,boolean Line6or9)
    {
        this.y_i_current = y_i_current;
        this.y_prim = y_prim;
        this.f_last = f_last;
        this.f_current = f_current;
        this.f_old = f_old;
        this.f_i = f_i;
        this.count_neighbour = count_neighbour;
        neighbour = neigh;
        neighbour_fi = neighbours_fi;
        this.iteration = iteration;
        this.num_neighbour = num_neighbour;
        this.EndofComputation = EndofComputation;
        this.count_End = count_End;
        this.Master_Prev = Master_Prev;
        this.Master_Current = Master_Current;
        this.Line6or9 = Line6or9;
        // this.Id = Id;this.Fi = Fi; this.Fi_t = Fi_t;
    }
    /*public void setf_old(double lastf) {
        this.f_old = lastf;
    }
    public void setf_current(double currentf) {
        this.f_current = currentf;
    }
    public void sety_prim(double y_prim) {
        this.y_prim = y_prim;
    }
    public void setf_i(double f_i) {
        this.f_i= f_i;
    }*/
    public long getCount() {
        return count_neighbour;
    }
    public long getIteration() {
        return iteration;
    }
    public long getnum_neighbour() {return num_neighbour;}
    public double getCurrentf() {
        return f_current;
    }
    public double getLastf() {
        return f_last;
    }
    public double gety_prim() {return y_prim;}
    public double getf_old() {
        return f_old;
    }
    public double getf_i() {
        return f_i;
    }
    public double gety_i() {
        return y_i_current;
    }
    public double[] getneighbour() {
        return neighbour;
    }
    public double[] getneighbours_fi() {
        return neighbour_fi;
    }
    public boolean IsEnd(){return EndofComputation;}
    public long getCount_End() {
        return count_End;
    }
    public long getMaster_Prev() {
        return Master_Prev;
    }
    public long getMaster_Current() {
        return Master_Current;
    }
    public boolean getLine6or9() {
        return Line6or9;
    }


    public void write(DataOutput dataOutput) throws IOException {
        dataOutput.writeDouble(y_i_current);
        dataOutput.writeDouble(y_prim);
        dataOutput.writeDouble(f_last);
        dataOutput.writeDouble(f_current);
        dataOutput.writeDouble(f_old);
        dataOutput.writeDouble(f_i);

    }
    public void readFields(DataInput dataInput) throws IOException {
        y_i_current = dataInput.readDouble();
        y_prim = dataInput.readDouble();
        f_last = dataInput.readDouble();
        f_current = dataInput.readDouble();
        f_old = dataInput.readDouble();
        f_i = dataInput.readDouble();
    }
}