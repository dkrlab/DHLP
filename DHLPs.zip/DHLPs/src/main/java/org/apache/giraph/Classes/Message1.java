package org.apache.giraph.Classes;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

/**
 * Created by erfan on 5/12/17.
 */
public class Message1 implements Writable {
    private long Id = 0;
   // private long Id = 0.0;
    private double Fi = 0.0;
    private double Fi_t = 0.0;
    private double neighbour = 0.0;
    private double y_i = 0.0;
    private boolean End = false;
    private boolean Master = false;
    private boolean Start = false;
    private boolean My_Final_Fi = false;

    public Message1(){

    }

 /*    public LPVertexValue(double y_i, double y_prim, double f_old, double f_current,double f_i) {
     set(y_i,y_prim,f_old,f_current,f_i);
/*        this.y_i = y_i;
        this.y_prim = y_prim;
        this.f_old = f_old;
        this.f_current = f_current;
        this.f_i = f_i;*/
    //}
 /*public void set(double y_i, double y_prim, double f_old, double f_current,double f_i)
 {
     this.y_i = y_i;
     this.y_prim = y_prim;
     this.f_old = f_old;
     this.f_current = f_current;
     this.f_i = f_i;
    // this.Id = Id;this.Fi = Fi; this.Fi_t = Fi_t;
 }
*/

    public Message1(long Id,double y_i, double Fi, double Fi_t, double neighbour, boolean End,boolean Master, boolean Start, boolean My_Final_Fi){
        set(Id,y_i,Fi,Fi_t,neighbour,End,Master,Start,My_Final_Fi);
    }
    public void write(DataOutput out)throws IOException{
        out.writeLong(Id);
        out.writeDouble(y_i);
        out.writeDouble(Fi);
        out.writeDouble(Fi_t);
        out.writeDouble(neighbour);
        out.writeBoolean(End);
        out.writeBoolean(Master);
        out.writeBoolean(Start);
        out.writeBoolean(My_Final_Fi);



    }
    public void readFields(DataInput in)throws IOException{
        Id = in.readLong();
        y_i = in.readDouble();
        Fi = in.readDouble();
        Fi_t = in.readDouble();
        neighbour = in.readDouble();
        End = in.readBoolean();
        Master = in.readBoolean();
        Start = in.readBoolean();
        My_Final_Fi = in.readBoolean();
    }
    public void set(long Id,double y_i,double Fi, double Fi_t,double neighbour, boolean End, boolean Master, boolean Start, boolean My_Final_Fi)
    {
        this.Id = Id;
        this.y_i =y_i;
        this.Fi = Fi;
        this.Fi_t = Fi_t;
        this.neighbour = neighbour;
        this.End = End;
        this.Master = Master;
        this.Start = Start;
        this.My_Final_Fi = My_Final_Fi;
    }
    public long get_Id(){return Id;}
    public double get_yi(){return y_i;}
    public double get_Fi(){return Fi;}
    public double get_Fit(){return Fi_t;}
    public double get_Neighbour(){return neighbour;}
    public boolean Is_End(){return End;}
    public boolean Is_Master(){return Master;}
    public boolean Is_Start(){return Start;}
    public boolean Is_Final_Fi(){return My_Final_Fi;}



   /* public int compareTo(Object o){
        Message1 other = (Message1)o;
        return (value<other.value?-1:(value==other.value?0:1));
    }
    public static class Comparator extends WritableComparator{
        public Comparator(){
            super(Message1.class);
        }
      public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2){
            double thisValue = readDouble(b1,s1);
            double thatValue = readDouble(b2,s2);
            return (thisValue<thatValue ? -1: (thisValue==thatValue?0:1));

      }
    }
    static {
        WritableComparator.define(Message1.class, new Comparator());
    }*/
}
